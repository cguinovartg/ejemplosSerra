import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { StorageType, NxPersistenceService } from '@allianz/core';

@Component({
  selector: 'app-football',
  templateUrl: './football.component.html',
  styleUrls: ['./football.component.scss']
})
export class FootballComponent implements OnInit {

  constructor() {}

  ngOnInit() { }
}
