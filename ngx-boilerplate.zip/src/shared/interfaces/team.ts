export class TeamDTO {
    name: string;
    description: string;
    color: string;
    stadium: boolean;
    fans: boolean;
    grass: boolean;
}
