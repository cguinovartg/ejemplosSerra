export const environment = {
  production: false,
  base_url: 'http://localhost:8080', // change to connect to mock server
  domain: 'localhost:8080' // domain localhost
};
