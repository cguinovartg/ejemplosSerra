export const environment = {
    production: false,
    base_url: 'https://wwwd.es.intrallianz.com', // url development server
    domain: 'wwwd.es.intrallianz.com' // domain development
};
