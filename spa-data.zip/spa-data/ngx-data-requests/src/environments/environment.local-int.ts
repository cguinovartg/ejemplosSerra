export const environment = {
    production: false,
    base_url: 'https://wwwi.es.intrallianz.com', // url integration server
    domain: 'wwwi.es.intrallianz.com' // domain integration
};
