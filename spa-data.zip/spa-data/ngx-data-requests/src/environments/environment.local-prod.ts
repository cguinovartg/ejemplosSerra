export const environment = {
    production: false,
    base_url: 'https://www.es.intrallianz.com', // url production server
    domain: 'www.es.intrallianz.com' // domain production
};
