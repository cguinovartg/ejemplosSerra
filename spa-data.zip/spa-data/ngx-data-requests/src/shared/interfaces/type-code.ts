export interface TypeCode {
    id: string;
    title: string;
}
