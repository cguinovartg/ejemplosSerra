export interface DateFrom {
    dateFrom: Date;
}
