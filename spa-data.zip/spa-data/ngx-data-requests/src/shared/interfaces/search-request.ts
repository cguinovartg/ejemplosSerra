export interface SearchRequest {
    userId: string;
    petitionNumber: string;
    reportType: string;
    creationDate: string;
    fullCreationDate: string;
    status: string;
    text: string;
    selectedDate: string;
    id: string;
}
