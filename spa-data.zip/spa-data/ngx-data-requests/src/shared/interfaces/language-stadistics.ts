export interface LanguageStadistics {
    id: number;
    language: string;
    total: number;
}
