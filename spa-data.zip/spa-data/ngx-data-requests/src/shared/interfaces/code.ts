export interface Code {
    code: string;
}
