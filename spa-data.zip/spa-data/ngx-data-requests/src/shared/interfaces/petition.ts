export interface PetitionProduct {
    code: string;
    description: string;
}
