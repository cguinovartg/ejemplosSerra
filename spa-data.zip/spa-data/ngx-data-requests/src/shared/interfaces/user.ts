export interface User {
    mediator: string;
    name: string;
    email: string;
}
