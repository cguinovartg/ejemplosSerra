export interface State {
    state: string;
}
