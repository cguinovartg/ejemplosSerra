export interface Mediator {
    accountManagerSubNumber?: string;
    agentNumber?: string;
    email?: string;
    firstName?: string;
    lastName?: string;
    roleNameOfAccountManager?: string;
    sucursal?: string;
    uc?: string;
}
