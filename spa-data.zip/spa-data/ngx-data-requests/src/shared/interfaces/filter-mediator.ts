export interface FilterMediator {
    mediator: string;
}
