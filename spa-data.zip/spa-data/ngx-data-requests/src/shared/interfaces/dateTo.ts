export interface DateTo {
    dateTo: Date;
}
