export interface Type {
    type: string;
}
