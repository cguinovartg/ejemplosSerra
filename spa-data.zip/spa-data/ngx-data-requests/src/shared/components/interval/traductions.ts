export interface NxTraductions {
  title: string;
  dateSince: string;
  dateUntil: string;
  dateType: string;
  informationCriterion: string;
  fiscalYear: string;
}
