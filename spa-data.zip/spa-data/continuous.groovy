rwsContinuousPipeline()
