rwsReleasePipeline()
