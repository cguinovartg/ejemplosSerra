package com.allianz.spa.data.requests.service;

public interface ConfigurationService {

	String getClientAppResourceId();

}
