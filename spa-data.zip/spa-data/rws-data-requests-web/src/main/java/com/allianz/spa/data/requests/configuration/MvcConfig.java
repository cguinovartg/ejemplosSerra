package com.allianz.spa.data.requests.configuration;

import org.springframework.context.annotation.Configuration;

import com.allianz.rest.support.config.MvcConfigBase;

@Configuration
public class MvcConfig extends MvcConfigBase {
}
