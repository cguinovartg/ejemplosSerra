package com.allianz.spa.data.requests.configuration;

import org.springframework.stereotype.Controller;

import com.allianz.rest.support.config.HomeControllerBase;

/**
 * Home redirection to swagger api documentation
 */
@Controller
public class HomeController extends HomeControllerBase {
	
}