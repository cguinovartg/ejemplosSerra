rwsPublishPipeline()
